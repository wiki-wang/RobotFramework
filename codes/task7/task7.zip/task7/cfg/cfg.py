mngLoginUrl = 'http://localhost/mgr/login/login.html'
adminuser = {'user': 'auto', 'pw': 'sdfsdfsdf' }