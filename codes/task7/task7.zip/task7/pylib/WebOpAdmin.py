from selenium import webdriver
import time
from selenium.webdriver.support.ui import Select

class WebOpAdmin():
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

    def __init__(self):
        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(10)

    def setupWebTest(self):
        self.driver.get('http://localhost')

    def tearDownWebTest(self):
        self.driver.quit()

    def loginWebSite(self, url, username, passwd):
        self.driver.get(url)
        self.driver.find_element_by_id('username').send_keys(username)
        self.driver.find_element_by_id('password').send_keys(passwd)
        self.driver.find_element_by_css_selector('button[onclick *= "postLoginRequest()"]').click()

    def selectCourseTab(self):
        self.driver.find_element_by_css_selector('a[ui-sref=course]').click()
        time.sleep(2)


    def deleteAllCourse(self):

        self.selectCourseTab()

        self.driver.implicitly_wait(2)
        while True:
            eles = self.driver.find_elements_by_css_selector('button[ng-click="delOne(one)"]')
            if len(eles) == 0:
                break
            eles[0].click()
            self.driver.find_element_by_css_selector('button.btn-primary').click()
            time.sleep(1)
        self.driver.implicitly_wait(10)


    def addCourse(self, name, desc, idx):

        self.selectCourseTab()

        self.driver.find_element_by_css_selector('button[ng-click*="showAddOne=true"]').click()

        self.driver.find_element_by_css_selector("input[ng-model*='addData.name']").clear()
        self.driver.find_element_by_css_selector("input[ng-model*='addData.name']").send_keys(name)

        self.driver.find_element_by_css_selector("textarea[ng-model*='addData.desc']").clear()
        self.driver.find_element_by_css_selector("textarea[ng-model*='addData.desc']").send_keys(desc)

        self.driver.find_element_by_css_selector('input[ng-model*="addData.display_idx"] ').clear()
        self.driver.find_element_by_css_selector('input[ng-model*="addData.display_idx"] ').send_keys(idx)

        self.driver.find_element_by_css_selector("button[ng-click*='addOne()']").click()

    def getCourseList(self):

        self.selectCourseTab()

        eles = self.driver.find_elements_by_css_selector('tr>td:nth-child(2)')
        return [ele.text for ele in eles]


    def selectTeacherTab(self):
        self.driver.find_element_by_css_selector("a[href='#/teacher']").click()
        time.sleep(2)


    def deleteAllTeachers(self):
        self.selectTeacherTab()
        self.driver.implicitly_wait(2)
        while True:
            eles = self.driver.find_elements_by_css_selector('button[ng-click="delOne(one)"]')
            if len(eles) == 0:
                break
            eles[0].click()
            self.driver.find_element_by_css_selector('button.btn-primary').click()
            time.sleep(1)
        self.driver.implicitly_wait(10)


    def addTeacher(self, name, course, loginname, desc, idx):

        self.selectTeacherTab()

        self.driver.find_element_by_css_selector('button[ng-click="showAddOne=true"]').click()

        self.driver.find_element_by_css_selector('input[ng-model="addEditData.realname"]').clear()
        self.driver.find_element_by_css_selector('input[ng-model="addEditData.realname"]').send_keys(name)

        self.driver.find_element_by_css_selector('input[ng-model = "addEditData.username"]').clear()
        self.driver.find_element_by_css_selector('input[ng-model = "addEditData.username"]').send_keys(loginname)

        self.driver.find_element_by_css_selector('textarea[ng-model="addEditData.desc"]').clear()
        self.driver.find_element_by_css_selector('textarea[ng-model="addEditData.desc"]').send_keys(desc)

        self.driver.find_element_by_css_selector('input[ng-model="addEditData.display_idx"]').clear()
        self.driver.find_element_by_css_selector('input[ng-model="addEditData.display_idx"]').send_keys(idx)

        # 如果有默认勾选项，先全部删除
        self.driver.implicitly_wait(2)
        eles = self.driver.find_elements_by_css_selector('button[ng-repeat*="course in addEditData"]')
        if eles != []:
            for ele in eles:
                ele.click()
        self.driver.implicitly_wait(10)

        select = Select(self.driver.find_element_by_css_selector('select[ng-options*=courseList]'))
        select.select_by_visible_text(course)
        self.driver.find_element_by_css_selector("button[ng-click *= addTeachCourse]").click()

        self.driver.find_element_by_css_selector("button[ng-click*='addOne()']").click()


    def getTeacherList(self):

        self.selectTeacherTab()

        eles = self.driver.find_elements_by_css_selector('tbody>tr>td:nth-child(2)')
        return [ele.text for ele in eles]



    def selectTrainingClassTab(self):
        self.driver.find_element_by_css_selector("a[href='#/training']").click()
        time.sleep(2)


    def deleteAllTrainingClasses(self):
        self.selectTrainingClassTab()
        self.driver.implicitly_wait(2)
        while True:
            eles = self.driver.find_elements_by_css_selector('button[ng-click="delOne(one)"]')
            if len(eles) == 0:
                break
            eles[0].click()
            self.driver.find_element_by_css_selector('button.btn-primary').click()
            time.sleep(1)
        self.driver.implicitly_wait(10)


    def addTrainingClass(self, name, desc, idx, *course):

        self.selectTrainingClassTab()

        self.driver.find_element_by_css_selector('button[ng-click="showAddOne=true"]').click()

        self.driver.find_element_by_css_selector('input[ng-model="addEditData.name"]').clear()
        self.driver.find_element_by_css_selector('input[ng-model="addEditData.name"]').send_keys(name)

        self.driver.find_element_by_css_selector('textarea[ng-model="addEditData.desc"]').clear()
        self.driver.find_element_by_css_selector('textarea[ng-model="addEditData.desc"]').send_keys(desc)

        self.driver.find_element_by_css_selector('input[ng-model="addEditData.display_idx"]').clear()
        self.driver.find_element_by_css_selector('input[ng-model="addEditData.display_idx"]').send_keys(idx)

        # 如果有默认勾选项，先全部删除
        self.driver.implicitly_wait(2)
        eles = self.driver.find_elements_by_css_selector('button[ng-repeat*="course in addEditData"]')
        if eles:
            for ele in eles:
                ele.click()
        self.driver.implicitly_wait(10)

        select = Select(self.driver.find_element_by_css_selector('select[ng-options*=courseList]'))
        for one in course:
            select.select_by_visible_text(one)
            self.driver.find_element_by_css_selector("button[ng-click *= addTeachCourse]").click()

        self.driver.find_element_by_css_selector("button[ng-click*='addOne()']").click()

    def getTrainingClassList(self):

        self.selectTrainingClassTab()

        eles = self.driver.find_elements_by_css_selector('tbody>tr>td:nth-child(2)')
        return [ele.text for ele in eles]




    def selectTrainingScheduleTab(self):
        self.driver.find_element_by_css_selector("a[href*='traininggrade']").click()
        time.sleep(2)


    def deleteAllTrainingSchedules(self):
        self.selectTrainingScheduleTab()
        self.driver.implicitly_wait(2)
        while True:
            eles = self.driver.find_elements_by_css_selector('button[ng-click="delOne(one)"]')
            if len(eles) == 0:
                break
            eles[0].click()
            self.driver.find_element_by_css_selector('button.btn-primary').click()
            time.sleep(1)
        self.driver.implicitly_wait(10)


    def addTrainingSchedule(self, name, desc, idx, trainingclass):

        self.selectTrainingScheduleTab()

        self.driver.find_element_by_css_selector('button[ng-click="showAddOne=true"]').click()

        self.driver.find_element_by_css_selector('input[ng-model="addEditData.name"]').clear()
        self.driver.find_element_by_css_selector('input[ng-model="addEditData.name"]').send_keys(name)

        self.driver.find_element_by_css_selector('textarea[ng-model="addEditData.desc"]').clear()
        self.driver.find_element_by_css_selector('textarea[ng-model="addEditData.desc"]').send_keys(desc)

        self.driver.find_element_by_css_selector('input[ng-model="addEditData.display_idx"]').clear()
        self.driver.find_element_by_css_selector('input[ng-model="addEditData.display_idx"]').send_keys(idx)

        select = Select(self.driver.find_element_by_css_selector("select[ng-model*='addEditData.training_id']"))
        select.select_by_visible_text(trainingclass)

        self.driver.find_element_by_css_selector("button[ng-click*='addOne()']").click()


    def getTrainingScheduleList(self):

        self.selectTrainingScheduleTab()

        eles = self.driver.find_elements_by_css_selector('tbody>tr>td:nth-child(2)')
        return [ele.text for ele in eles]

